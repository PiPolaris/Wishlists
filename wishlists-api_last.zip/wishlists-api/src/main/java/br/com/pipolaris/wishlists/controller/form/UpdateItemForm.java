package br.com.pipolaris.wishlists.controller.form;

public class UpdateItemForm {

}
